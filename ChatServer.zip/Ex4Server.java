/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author student
 */
public class Ex4Server {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ex4Server server = new Ex4Server();
        server.runServer();
    }
    
    private ServerSocket server;
    ArrayList sockets = new ArrayList();
    
    public void runServer(){
        try{
            this.server = new ServerSocket(8000);
            System.out.println("サーバが起動しました。");
        }catch(IOException e){
            System.out.println("このポートは既に使用されています。");
        }
        
        int i=0;
        while(i < 32){
            i+=1;
            Socket socket;
            try {
                socket = server.accept();
                System.out.println("クライアント"+ i +"と接続されました。");
                sockets.add(socket);
                int socketNum = i;
                Thread chatTh = new Thread(){ 
                    @Override
                    public void run(){
                        Ex4Server.this.chatThread(socket);
                    }
                };
                chatTh.start();
            } catch (IOException ex) {
                System.out.println("クライアントとの接続に問題があります。");
            }
        }
    }
    
    private void chatThread(Socket socket){
        
        String line;
        int clientID = 0;
        String name = "none";
        System.out.println(socket);
        
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            line = reader.readLine();
            name = line;
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
            writer.println(name + "さん　ようこそ");
            writer.flush();
            
        } catch (IOException ex) {
            Logger.getLogger(Ex4Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        for(int i = 0;i < this.sockets.size();i++){
            if(this.sockets.get(i).equals(socket)){
                clientID = i + 1;
            }
        }
        
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while((line = reader.readLine()) != null){
                System.out.println("[Reserve]" + name + ":" + line);
                this.chatSend(line, name, clientID);
            }
        } catch (IOException ex) {
            System.out.println("クライアント" + clientID + "が切断されました。");
        }
    }
    
    private void chatSend(String line, String name, int clientID){
        for(int i = 0; i < this.sockets.size(); i++){
            if(clientID == i+1){
                continue;
            }
            Socket so = (Socket) this.sockets.get(i);
            try {
                PrintWriter writer;
                writer = new PrintWriter(new OutputStreamWriter(so.getOutputStream()));
                writer.println("[" + name + "]" + line);
                writer.flush();
            } catch (IOException ex) {
                Logger.getLogger(Ex4Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author plane
 */
public class ServerThread extends Thread {
    private final Socket socket;
    private String Name;
    private final int clientID;
    private ChatServer server;
    
    public ServerThread(Socket socket, int id, ChatServer server){
        this.socket = socket;
        this.clientID = id;
        this.server = server;
    }
    
    @Override
    public void run(){
        String line;
        System.out.println(socket);
        
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            line = reader.readLine();
            this.Name = line;
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
            writer.println(this.Name + "さん　ようこそ");
            writer.flush();
            
        } catch (IOException ex) {
            System.out.println("クライアント" + clientID + "が切断されました。");
        }
        
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while((line = reader.readLine()) != null){
                System.out.println("[Reserve]" + this.Name + ":" + line);
                server.chatSend(line, this.Name, this.clientID);
            }
        } catch (IOException ex) {
            System.out.println("クライアント" + clientID + "が切断されました。");
        }
    }
    
}
